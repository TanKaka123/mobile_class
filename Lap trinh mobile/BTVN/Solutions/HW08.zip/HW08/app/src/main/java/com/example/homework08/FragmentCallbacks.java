package com.example.homework08;

public interface FragmentCallbacks {
    public void onMsgFromMainToFragment(int position);
}
package com.example.homework05;

public interface FragmentCallbacks {
    public void onMsgFromMainToFragment(int position);
}
package com.example.homework05;

public interface MainCallbacks {
    public void onMsgFromFragToMain(String sender, int position);
}
